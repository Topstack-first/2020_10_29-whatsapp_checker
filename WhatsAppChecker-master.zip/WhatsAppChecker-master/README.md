# Running

- Install node and npm (see http://nodejs.org/)
- Run `npm install` from this directory to install dependencies
- Run `node app.js` to start the server on port 8080
- Go to [http://localhost:8080](http://localhost:8080) in your browser